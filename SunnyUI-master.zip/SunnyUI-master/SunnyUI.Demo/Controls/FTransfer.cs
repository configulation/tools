﻿namespace Sunny.UI.Demo
{
    public partial class FTransfer : UIPage
    {
        public FTransfer()
        {
            InitializeComponent();
        }
    }
}
