﻿
namespace Sunny.UI.Demo
{
    partial class FNavigation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("节点15");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("节点16");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("节点17");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("节点18");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("节点19");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("节点20");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("节点15");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("节点16");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("节点17");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25});
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("节点18");
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("节点19");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("节点20");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode27,
            treeNode28,
            treeNode29});
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("节点9");
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("节点10");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("节点0");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode43,
            treeNode44,
            treeNode45});
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode46,
            treeNode47,
            treeNode48,
            treeNode49});
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode51,
            treeNode52,
            treeNode53});
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("节点8");
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("节点2", new System.Windows.Forms.TreeNode[] {
            treeNode55,
            treeNode56});
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("节点3");
            this.uiLine2 = new Sunny.UI.UILine();
            this.uiNavMenu2 = new Sunny.UI.UINavMenu();
            this.uiNavMenu1 = new Sunny.UI.UINavMenu();
            this.uiNavBar1 = new Sunny.UI.UINavBar();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiNavBar1.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiLine2
            // 
            this.uiLine2.BackColor = System.Drawing.Color.Transparent;
            this.uiLine2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine2.Location = new System.Drawing.Point(30, 160);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(670, 20);
            this.uiLine2.TabIndex = 23;
            this.uiLine2.Text = "UINavMenu";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiNavMenu2
            // 
            this.uiNavMenu2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.uiNavMenu2.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.uiNavMenu2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiNavMenu2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu2.FullRowSelect = true;
            this.uiNavMenu2.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.uiNavMenu2.ItemHeight = 50;
            this.uiNavMenu2.Location = new System.Drawing.Point(299, 192);
            this.uiNavMenu2.MenuStyle = Sunny.UI.UIMenuStyle.White;
            this.uiNavMenu2.Name = "uiNavMenu2";
            treeNode1.Name = "节点14";
            treeNode1.Text = "节点14";
            treeNode2.Name = "节点15";
            treeNode2.Text = "节点15";
            treeNode3.Name = "节点16";
            treeNode3.Text = "节点16";
            treeNode4.Name = "节点17";
            treeNode4.Text = "节点17";
            treeNode5.Name = "节点0";
            treeNode5.Text = "节点0";
            treeNode6.Name = "节点18";
            treeNode6.Text = "节点18";
            treeNode7.Name = "节点19";
            treeNode7.Text = "节点19";
            treeNode8.Name = "节点20";
            treeNode8.Text = "节点20";
            treeNode9.Name = "节点1";
            treeNode9.Text = "节点1";
            treeNode10.Name = "节点2";
            treeNode10.Text = "节点2";
            treeNode11.Name = "节点3";
            treeNode11.Text = "节点3";
            treeNode12.Name = "节点4";
            treeNode12.Text = "节点4";
            treeNode13.Name = "节点5";
            treeNode13.Text = "节点5";
            treeNode14.Name = "节点6";
            treeNode14.Text = "节点6";
            treeNode15.Name = "节点7";
            treeNode15.Text = "节点7";
            treeNode16.Name = "节点8";
            treeNode16.Text = "节点8";
            treeNode17.Name = "节点9";
            treeNode17.Text = "节点9";
            treeNode18.Name = "节点10";
            treeNode18.Text = "节点10";
            treeNode19.Name = "节点11";
            treeNode19.Text = "节点11";
            treeNode20.Name = "节点12";
            treeNode20.Text = "节点12";
            treeNode21.Name = "节点13";
            treeNode21.Text = "节点13";
            this.uiNavMenu2.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode9,
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13,
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17,
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21});
            this.uiNavMenu2.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu2.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu2.ScrollBarPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu2.ScrollFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu2.SecondBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.uiNavMenu2.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiNavMenu2.SelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiNavMenu2.ShowLines = false;
            this.uiNavMenu2.Size = new System.Drawing.Size(253, 353);
            this.uiNavMenu2.TabIndex = 22;
            this.uiNavMenu2.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiNavMenu1
            // 
            this.uiNavMenu1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.uiNavMenu1.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.uiNavMenu1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiNavMenu1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu1.FullRowSelect = true;
            this.uiNavMenu1.ItemHeight = 50;
            this.uiNavMenu1.Location = new System.Drawing.Point(30, 192);
            this.uiNavMenu1.MenuStyle = Sunny.UI.UIMenuStyle.Custom;
            this.uiNavMenu1.Name = "uiNavMenu1";
            treeNode22.Name = "节点14";
            treeNode22.Text = "节点14";
            treeNode23.Name = "节点15";
            treeNode23.Text = "节点15";
            treeNode24.Name = "节点16";
            treeNode24.Text = "节点16";
            treeNode25.Name = "节点17";
            treeNode25.Text = "节点17";
            treeNode26.Name = "节点0";
            treeNode26.Text = "节点0";
            treeNode27.Name = "节点18";
            treeNode27.Text = "节点18";
            treeNode28.Name = "节点19";
            treeNode28.Text = "节点19";
            treeNode29.Name = "节点20";
            treeNode29.Text = "节点20";
            treeNode30.Name = "节点1";
            treeNode30.Text = "节点1";
            treeNode31.Name = "节点2";
            treeNode31.Text = "节点2";
            treeNode32.Name = "节点3";
            treeNode32.Text = "节点3";
            treeNode33.Name = "节点4";
            treeNode33.Text = "节点4";
            treeNode34.Name = "节点5";
            treeNode34.Text = "节点5";
            treeNode35.Name = "节点6";
            treeNode35.Text = "节点6";
            treeNode36.Name = "节点7";
            treeNode36.Text = "节点7";
            treeNode37.Name = "节点8";
            treeNode37.Text = "节点8";
            treeNode38.Name = "节点9";
            treeNode38.Text = "节点9";
            treeNode39.Name = "节点10";
            treeNode39.Text = "节点10";
            treeNode40.Name = "节点11";
            treeNode40.Text = "节点11";
            treeNode41.Name = "节点12";
            treeNode41.Text = "节点12";
            treeNode42.Name = "节点13";
            treeNode42.Text = "节点13";
            this.uiNavMenu1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode26,
            treeNode30,
            treeNode31,
            treeNode32,
            treeNode33,
            treeNode34,
            treeNode35,
            treeNode36,
            treeNode37,
            treeNode38,
            treeNode39,
            treeNode40,
            treeNode41,
            treeNode42});
            this.uiNavMenu1.ShowLines = false;
            this.uiNavMenu1.Size = new System.Drawing.Size(253, 353);
            this.uiNavMenu1.TabIndex = 21;
            this.uiNavMenu1.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiNavMenu1.MenuItemClick += new Sunny.UI.UINavMenu.OnMenuItemClick(this.uiNavMenu1_MenuItemClick);
            // 
            // uiNavBar1
            // 
            this.uiNavBar1.Controls.Add(this.uiLine1);
            this.uiNavBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.uiNavBar1.DropMenuFont = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiNavBar1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiNavBar1.Location = new System.Drawing.Point(0, 35);
            this.uiNavBar1.Name = "uiNavBar1";
            this.uiNavBar1.NodeAlignment = System.Drawing.StringAlignment.Near;
            treeNode43.Name = "节点0";
            treeNode43.Text = "节点0";
            treeNode44.Name = "节点1";
            treeNode44.Text = "节点1";
            treeNode45.Name = "节点2";
            treeNode45.Text = "节点2";
            treeNode46.Name = "节点0";
            treeNode46.Text = "节点0";
            treeNode47.Name = "节点1";
            treeNode47.Text = "节点1";
            treeNode48.Name = "节点2";
            treeNode48.Text = "节点2";
            treeNode49.Name = "节点3";
            treeNode49.Text = "节点3";
            treeNode50.Name = "节点0";
            treeNode50.Text = "节点0";
            treeNode51.Name = "节点4";
            treeNode51.Text = "节点4";
            treeNode52.Name = "节点5";
            treeNode52.Text = "节点5";
            treeNode53.Name = "节点6";
            treeNode53.Text = "节点6";
            treeNode54.Name = "节点1";
            treeNode54.Text = "节点1";
            treeNode55.Name = "节点7";
            treeNode55.Text = "节点7";
            treeNode56.Name = "节点8";
            treeNode56.Text = "节点8";
            treeNode57.Name = "节点2";
            treeNode57.Text = "节点2";
            treeNode58.Name = "节点3";
            treeNode58.Text = "节点3";
            this.uiNavBar1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode50,
            treeNode54,
            treeNode57,
            treeNode58});
            this.uiNavBar1.Size = new System.Drawing.Size(800, 110);
            this.uiNavBar1.TabIndex = 20;
            this.uiNavBar1.Text = "uiNavBar1";
            this.uiNavBar1.MenuItemClick += new Sunny.UI.UINavBar.OnMenuItemClick(this.uiNavBar1_MenuItemClick);
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.uiLine1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine1.ForeColor = System.Drawing.Color.White;
            this.uiLine1.Location = new System.Drawing.Point(30, 20);
            this.uiLine1.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(670, 20);
            this.uiLine1.Style = Sunny.UI.UIStyle.Custom;
            this.uiLine1.StyleCustomMode = true;
            this.uiLine1.TabIndex = 20;
            this.uiLine1.Text = "UINavBar";
            this.uiLine1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FNavigation
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 603);
            this.Controls.Add(this.uiLine2);
            this.Controls.Add(this.uiNavMenu2);
            this.Controls.Add(this.uiNavMenu1);
            this.Controls.Add(this.uiNavBar1);
            this.Name = "FNavigation";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 61912;
            this.Text = "Navigation";
            this.uiNavBar1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private UILine uiLine2;
        private UINavMenu uiNavMenu2;
        private UINavMenu uiNavMenu1;
        private UINavBar uiNavBar1;
        private UILine uiLine1;
    }
}