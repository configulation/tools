﻿
namespace Sunny.UI.Demo
{
    partial class FLabel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiMarkLabel4 = new Sunny.UI.UIMarkLabel();
            this.uiMarkLabel3 = new Sunny.UI.UIMarkLabel();
            this.uiMarkLabel2 = new Sunny.UI.UIMarkLabel();
            this.uiLine4 = new Sunny.UI.UILine();
            this.uiMarkLabel1 = new Sunny.UI.UIMarkLabel();
            this.uiSymbolLabel2 = new Sunny.UI.UISymbolLabel();
            this.uiSymbolLabel1 = new Sunny.UI.UISymbolLabel();
            this.uiLine3 = new Sunny.UI.UILine();
            this.uiLine2 = new Sunny.UI.UILine();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiLinkLabel1 = new Sunny.UI.UILinkLabel();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiLabel4 = new Sunny.UI.UILabel();
            this.uiLine5 = new Sunny.UI.UILine();
            this.uiSmoothLabel1 = new Sunny.UI.UISmoothLabel();
            this.uiSmoothLabel2 = new Sunny.UI.UISmoothLabel();
            this.uiLine6 = new Sunny.UI.UILine();
            this.SuspendLayout();
            // 
            // uiMarkLabel4
            // 
            this.uiMarkLabel4.AutoSize = true;
            this.uiMarkLabel4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiMarkLabel4.Location = new System.Drawing.Point(508, 242);
            this.uiMarkLabel4.MarkPos = Sunny.UI.UIMarkLabel.UIMarkPos.Top;
            this.uiMarkLabel4.Name = "uiMarkLabel4";
            this.uiMarkLabel4.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.uiMarkLabel4.Size = new System.Drawing.Size(113, 26);
            this.uiMarkLabel4.TabIndex = 45;
            this.uiMarkLabel4.Text = "uiMarkLabel4";
            this.uiMarkLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiMarkLabel3
            // 
            this.uiMarkLabel3.AutoSize = true;
            this.uiMarkLabel3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiMarkLabel3.Location = new System.Drawing.Point(199, 245);
            this.uiMarkLabel3.MarkPos = Sunny.UI.UIMarkLabel.UIMarkPos.Right;
            this.uiMarkLabel3.Name = "uiMarkLabel3";
            this.uiMarkLabel3.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.uiMarkLabel3.Size = new System.Drawing.Size(118, 21);
            this.uiMarkLabel3.TabIndex = 44;
            this.uiMarkLabel3.Text = "uiMarkLabel3";
            this.uiMarkLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiMarkLabel2
            // 
            this.uiMarkLabel2.AutoSize = true;
            this.uiMarkLabel2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiMarkLabel2.Location = new System.Drawing.Point(356, 242);
            this.uiMarkLabel2.MarkPos = Sunny.UI.UIMarkLabel.UIMarkPos.Bottom;
            this.uiMarkLabel2.Name = "uiMarkLabel2";
            this.uiMarkLabel2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.uiMarkLabel2.Size = new System.Drawing.Size(113, 26);
            this.uiMarkLabel2.TabIndex = 43;
            this.uiMarkLabel2.Text = "uiMarkLabel2";
            this.uiMarkLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine4
            // 
            this.uiLine4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine4.Location = new System.Drawing.Point(30, 208);
            this.uiLine4.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine4.Name = "uiLine4";
            this.uiLine4.Size = new System.Drawing.Size(670, 20);
            this.uiLine4.TabIndex = 42;
            this.uiLine4.Text = "UIMarkLabel";
            this.uiLine4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiMarkLabel1
            // 
            this.uiMarkLabel1.AutoSize = true;
            this.uiMarkLabel1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiMarkLabel1.Location = new System.Drawing.Point(42, 245);
            this.uiMarkLabel1.Name = "uiMarkLabel1";
            this.uiMarkLabel1.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.uiMarkLabel1.Size = new System.Drawing.Size(118, 21);
            this.uiMarkLabel1.TabIndex = 41;
            this.uiMarkLabel1.Text = "uiMarkLabel1";
            this.uiMarkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSymbolLabel2
            // 
            this.uiSymbolLabel2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolLabel2.Location = new System.Drawing.Point(139, 169);
            this.uiSymbolLabel2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolLabel2.Name = "uiSymbolLabel2";
            this.uiSymbolLabel2.Size = new System.Drawing.Size(91, 24);
            this.uiSymbolLabel2.Symbol = 61453;
            this.uiSymbolLabel2.TabIndex = 40;
            this.uiSymbolLabel2.Text = "Cancel";
            this.uiSymbolLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSymbolLabel1
            // 
            this.uiSymbolLabel1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolLabel1.Location = new System.Drawing.Point(42, 169);
            this.uiSymbolLabel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolLabel1.Name = "uiSymbolLabel1";
            this.uiSymbolLabel1.Size = new System.Drawing.Size(91, 24);
            this.uiSymbolLabel1.TabIndex = 39;
            this.uiSymbolLabel1.Text = "OK";
            this.uiSymbolLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine3
            // 
            this.uiLine3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine3.Location = new System.Drawing.Point(30, 133);
            this.uiLine3.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(670, 20);
            this.uiLine3.TabIndex = 38;
            this.uiLine3.Text = "UISymbolLabel";
            this.uiLine3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine2
            // 
            this.uiLine2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine2.Location = new System.Drawing.Point(381, 55);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(319, 20);
            this.uiLine2.TabIndex = 37;
            this.uiLine2.Text = "UILinkLabel";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine1
            // 
            this.uiLine1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine1.Location = new System.Drawing.Point(30, 55);
            this.uiLine1.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(319, 20);
            this.uiLine1.TabIndex = 36;
            this.uiLine1.Text = "UILabel";
            this.uiLine1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLinkLabel1
            // 
            this.uiLinkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiLinkLabel1.AutoSize = true;
            this.uiLinkLabel1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.uiLinkLabel1.Location = new System.Drawing.Point(394, 90);
            this.uiLinkLabel1.Name = "uiLinkLabel1";
            this.uiLinkLabel1.Size = new System.Drawing.Size(146, 21);
            this.uiLinkLabel1.TabIndex = 35;
            this.uiLinkLabel1.TabStop = true;
            this.uiLinkLabel1.Text = "www.SunnyUI.net";
            this.uiLinkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiLinkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.uiLinkLabel1_LinkClicked);
            // 
            // uiLabel1
            // 
            this.uiLabel1.AutoSize = true;
            this.uiLabel1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel1.Location = new System.Drawing.Point(42, 90);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(102, 21);
            this.uiLabel1.TabIndex = 34;
            this.uiLabel1.Text = "Hello world!";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel2
            // 
            this.uiLabel2.Angle = 270;
            this.uiLabel2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel2.Location = new System.Drawing.Point(38, 297);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(43, 126);
            this.uiLabel2.TabIndex = 46;
            this.uiLabel2.Text = "Angle=270°";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel3
            // 
            this.uiLabel3.Angle = 90;
            this.uiLabel3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel3.Location = new System.Drawing.Point(90, 304);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(43, 126);
            this.uiLabel3.TabIndex = 47;
            this.uiLabel3.Text = "Angle=90°";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel4
            // 
            this.uiLabel4.Angle = 315;
            this.uiLabel4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel4.Location = new System.Drawing.Point(160, 297);
            this.uiLabel4.Name = "uiLabel4";
            this.uiLabel4.Size = new System.Drawing.Size(103, 126);
            this.uiLabel4.TabIndex = 48;
            this.uiLabel4.Text = "Angle=315°";
            this.uiLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLine5
            // 
            this.uiLine5.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine5.Location = new System.Drawing.Point(30, 290);
            this.uiLine5.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine5.Name = "uiLine5";
            this.uiLine5.Size = new System.Drawing.Size(319, 20);
            this.uiLine5.TabIndex = 49;
            this.uiLine5.Text = "UILabel（旋转角度）";
            this.uiLine5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSmoothLabel1
            // 
            this.uiSmoothLabel1.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiSmoothLabel1.Location = new System.Drawing.Point(381, 313);
            this.uiSmoothLabel1.Name = "uiSmoothLabel1";
            this.uiSmoothLabel1.RectSize = 3;
            this.uiSmoothLabel1.Size = new System.Drawing.Size(258, 66);
            this.uiSmoothLabel1.TabIndex = 53;
            this.uiSmoothLabel1.Text = "SunnyUI";
            // 
            // uiSmoothLabel2
            // 
            this.uiSmoothLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiSmoothLabel2.Location = new System.Drawing.Point(381, 386);
            this.uiSmoothLabel2.Name = "uiSmoothLabel2";
            this.uiSmoothLabel2.Size = new System.Drawing.Size(284, 83);
            this.uiSmoothLabel2.TabIndex = 54;
            this.uiSmoothLabel2.Text = "SunnyUI";
            // 
            // uiLine6
            // 
            this.uiLine6.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine6.Location = new System.Drawing.Point(381, 290);
            this.uiLine6.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine6.Name = "uiLine6";
            this.uiLine6.Size = new System.Drawing.Size(319, 20);
            this.uiLine6.TabIndex = 55;
            this.uiLine6.Text = "UISmoothLabel";
            this.uiLine6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FLabel
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 504);
            this.Controls.Add(this.uiLine6);
            this.Controls.Add(this.uiSmoothLabel2);
            this.Controls.Add(this.uiSmoothLabel1);
            this.Controls.Add(this.uiLine5);
            this.Controls.Add(this.uiLabel4);
            this.Controls.Add(this.uiLabel3);
            this.Controls.Add(this.uiLabel2);
            this.Controls.Add(this.uiMarkLabel4);
            this.Controls.Add(this.uiMarkLabel3);
            this.Controls.Add(this.uiMarkLabel2);
            this.Controls.Add(this.uiLine4);
            this.Controls.Add(this.uiMarkLabel1);
            this.Controls.Add(this.uiSymbolLabel2);
            this.Controls.Add(this.uiSymbolLabel1);
            this.Controls.Add(this.uiLine3);
            this.Controls.Add(this.uiLine2);
            this.Controls.Add(this.uiLine1);
            this.Controls.Add(this.uiLinkLabel1);
            this.Controls.Add(this.uiLabel1);
            this.Name = "FLabel";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 61490;
            this.Text = "Label";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private UIMarkLabel uiMarkLabel4;
        private UIMarkLabel uiMarkLabel3;
        private UIMarkLabel uiMarkLabel2;
        private UILine uiLine4;
        private UIMarkLabel uiMarkLabel1;
        private UISymbolLabel uiSymbolLabel2;
        private UISymbolLabel uiSymbolLabel1;
        private UILine uiLine3;
        private UILine uiLine2;
        private UILine uiLine1;
        private UILinkLabel uiLinkLabel1;
        private UILabel uiLabel1;
        private UILabel uiLabel2;
        private UILabel uiLabel3;
        private UILabel uiLabel4;
        private UILine uiLine5;
        private UISmoothLabel uiSmoothLabel1;
        private UISmoothLabel uiSmoothLabel2;
        private UILine uiLine6;
    }
}