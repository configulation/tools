﻿namespace Sunny.UI.Demo
{
    public partial class FHeaderButton : UIPage
    {
        public FHeaderButton()
        {
            InitializeComponent();
        }
    }
}
