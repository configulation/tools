﻿namespace Sunny.UI.Demo
{
    public partial class FTreeView : UIPage
    {
        public FTreeView()
        {
            InitializeComponent();
        }
    }
}
