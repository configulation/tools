﻿
namespace Sunny.UI.Demo
{
    partial class FRadioButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiButton4 = new Sunny.UI.UIButton();
            this.uiButton2 = new Sunny.UI.UIButton();
            this.uiRadioButtonGroup1 = new Sunny.UI.UIRadioButtonGroup();
            this.uiRadioButton12 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton13 = new Sunny.UI.UIRadioButton();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiRadioButton9 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton10 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton11 = new Sunny.UI.UIRadioButton();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.uiRadioButton5 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton7 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton8 = new Sunny.UI.UIRadioButton();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiRadioButton6 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton3 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton4 = new Sunny.UI.UIRadioButton();
            this.uiLine3 = new Sunny.UI.UILine();
            this.uiRadioButton2 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton1 = new Sunny.UI.UIRadioButton();
            this.uiLine2 = new Sunny.UI.UILine();
            this.SuspendLayout();
            // 
            // uiButton4
            // 
            this.uiButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton4.Location = new System.Drawing.Point(145, 481);
            this.uiButton4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton4.Name = "uiButton4";
            this.uiButton4.Size = new System.Drawing.Size(100, 35);
            this.uiButton4.TabIndex = 86;
            this.uiButton4.Text = "选择";
            this.uiButton4.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton4.Click += new System.EventHandler(this.uiButton4_Click);
            // 
            // uiButton2
            // 
            this.uiButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton2.Location = new System.Drawing.Point(30, 481);
            this.uiButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton2.Name = "uiButton2";
            this.uiButton2.Size = new System.Drawing.Size(100, 35);
            this.uiButton2.TabIndex = 85;
            this.uiButton2.Text = "全不选";
            this.uiButton2.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton2.Click += new System.EventHandler(this.uiButton2_Click);
            // 
            // uiRadioButtonGroup1
            // 
            this.uiRadioButtonGroup1.ColumnCount = 3;
            this.uiRadioButtonGroup1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButtonGroup1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.uiRadioButtonGroup1.Location = new System.Drawing.Point(30, 288);
            this.uiRadioButtonGroup1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiRadioButtonGroup1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButtonGroup1.Name = "uiRadioButtonGroup1";
            this.uiRadioButtonGroup1.Padding = new System.Windows.Forms.Padding(0, 32, 0, 0);
            this.uiRadioButtonGroup1.Size = new System.Drawing.Size(670, 173);
            this.uiRadioButtonGroup1.TabIndex = 84;
            this.uiRadioButtonGroup1.Text = "UIRadioButtonGroup";
            this.uiRadioButtonGroup1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiRadioButtonGroup1.ValueChanged += new Sunny.UI.UIRadioButtonGroup.OnValueChanged(this.uiRadioButtonGroup1_ValueChanged);
            // 
            // uiRadioButton12
            // 
            this.uiRadioButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton12.Enabled = false;
            this.uiRadioButton12.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton12.GroupIndex = 4;
            this.uiRadioButton12.Location = new System.Drawing.Point(516, 83);
            this.uiRadioButton12.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton12.Name = "uiRadioButton12";
            this.uiRadioButton12.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton12.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton12.TabIndex = 83;
            this.uiRadioButton12.Text = "uiRadioButton12";
            // 
            // uiRadioButton13
            // 
            this.uiRadioButton13.Checked = true;
            this.uiRadioButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton13.Enabled = false;
            this.uiRadioButton13.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton13.GroupIndex = 4;
            this.uiRadioButton13.Location = new System.Drawing.Point(354, 83);
            this.uiRadioButton13.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton13.Name = "uiRadioButton13";
            this.uiRadioButton13.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton13.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton13.TabIndex = 82;
            this.uiRadioButton13.Text = "uiRadioButton13";
            // 
            // uiLabel3
            // 
            this.uiLabel3.AutoSize = true;
            this.uiLabel3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel3.Location = new System.Drawing.Point(49, 254);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(119, 16);
            this.uiLabel3.TabIndex = 81;
            this.uiLabel3.Text = "GroupIndex = 3";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton9
            // 
            this.uiRadioButton9.Checked = true;
            this.uiRadioButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton9.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton9.GroupIndex = 3;
            this.uiRadioButton9.Location = new System.Drawing.Point(516, 247);
            this.uiRadioButton9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton9.Name = "uiRadioButton9";
            this.uiRadioButton9.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton9.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton9.TabIndex = 80;
            this.uiRadioButton9.Text = "uiRadioButton33";
            // 
            // uiRadioButton10
            // 
            this.uiRadioButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton10.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton10.GroupIndex = 3;
            this.uiRadioButton10.Location = new System.Drawing.Point(354, 247);
            this.uiRadioButton10.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton10.Name = "uiRadioButton10";
            this.uiRadioButton10.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton10.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton10.TabIndex = 79;
            this.uiRadioButton10.Text = "uiRadioButton32";
            // 
            // uiRadioButton11
            // 
            this.uiRadioButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton11.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton11.GroupIndex = 3;
            this.uiRadioButton11.Location = new System.Drawing.Point(192, 247);
            this.uiRadioButton11.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton11.Name = "uiRadioButton11";
            this.uiRadioButton11.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton11.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton11.TabIndex = 78;
            this.uiRadioButton11.Text = "uiRadioButton31";
            // 
            // uiLabel2
            // 
            this.uiLabel2.AutoSize = true;
            this.uiLabel2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel2.Location = new System.Drawing.Point(49, 213);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(119, 16);
            this.uiLabel2.TabIndex = 77;
            this.uiLabel2.Text = "GroupIndex = 2";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton5
            // 
            this.uiRadioButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton5.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton5.GroupIndex = 2;
            this.uiRadioButton5.Location = new System.Drawing.Point(516, 206);
            this.uiRadioButton5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton5.Name = "uiRadioButton5";
            this.uiRadioButton5.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton5.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton5.TabIndex = 76;
            this.uiRadioButton5.Text = "uiRadioButton23";
            // 
            // uiRadioButton7
            // 
            this.uiRadioButton7.Checked = true;
            this.uiRadioButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton7.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton7.GroupIndex = 2;
            this.uiRadioButton7.Location = new System.Drawing.Point(354, 206);
            this.uiRadioButton7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton7.Name = "uiRadioButton7";
            this.uiRadioButton7.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton7.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton7.TabIndex = 75;
            this.uiRadioButton7.Text = "uiRadioButton22";
            // 
            // uiRadioButton8
            // 
            this.uiRadioButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton8.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton8.GroupIndex = 2;
            this.uiRadioButton8.Location = new System.Drawing.Point(192, 206);
            this.uiRadioButton8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton8.Name = "uiRadioButton8";
            this.uiRadioButton8.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton8.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton8.TabIndex = 74;
            this.uiRadioButton8.Text = "uiRadioButton21";
            // 
            // uiLabel1
            // 
            this.uiLabel1.AutoSize = true;
            this.uiLabel1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel1.Location = new System.Drawing.Point(49, 172);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(119, 16);
            this.uiLabel1.TabIndex = 73;
            this.uiLabel1.Text = "GroupIndex = 1";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton6
            // 
            this.uiRadioButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton6.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton6.GroupIndex = 1;
            this.uiRadioButton6.Location = new System.Drawing.Point(516, 165);
            this.uiRadioButton6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton6.Name = "uiRadioButton6";
            this.uiRadioButton6.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton6.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton6.TabIndex = 72;
            this.uiRadioButton6.Text = "uiRadioButton13";
            // 
            // uiRadioButton3
            // 
            this.uiRadioButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton3.GroupIndex = 1;
            this.uiRadioButton3.Location = new System.Drawing.Point(354, 165);
            this.uiRadioButton3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton3.Name = "uiRadioButton3";
            this.uiRadioButton3.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton3.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton3.TabIndex = 71;
            this.uiRadioButton3.Text = "uiRadioButton12";
            // 
            // uiRadioButton4
            // 
            this.uiRadioButton4.Checked = true;
            this.uiRadioButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton4.GroupIndex = 1;
            this.uiRadioButton4.Location = new System.Drawing.Point(192, 165);
            this.uiRadioButton4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton4.Name = "uiRadioButton4";
            this.uiRadioButton4.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton4.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton4.TabIndex = 70;
            this.uiRadioButton4.Text = "uiRadioButton11";
            // 
            // uiLine3
            // 
            this.uiLine3.BackColor = System.Drawing.Color.Transparent;
            this.uiLine3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine3.Location = new System.Drawing.Point(30, 131);
            this.uiLine3.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(670, 20);
            this.uiLine3.TabIndex = 69;
            this.uiLine3.Text = "UIRadioButton 分组";
            this.uiLine3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton2
            // 
            this.uiRadioButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton2.Location = new System.Drawing.Point(192, 83);
            this.uiRadioButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton2.Name = "uiRadioButton2";
            this.uiRadioButton2.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton2.Size = new System.Drawing.Size(150, 35);
            this.uiRadioButton2.TabIndex = 68;
            this.uiRadioButton2.Text = "uiRadioButton2";
            // 
            // uiRadioButton1
            // 
            this.uiRadioButton1.Checked = true;
            this.uiRadioButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiRadioButton1.Location = new System.Drawing.Point(30, 83);
            this.uiRadioButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButton1.Name = "uiRadioButton1";
            this.uiRadioButton1.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton1.Size = new System.Drawing.Size(150, 35);
            this.uiRadioButton1.TabIndex = 67;
            this.uiRadioButton1.Text = "uiRadioButton1";
            this.uiRadioButton1.CheckedChanged += new System.EventHandler(this.uiRadioButton1_CheckedChanged);
            // 
            // uiLine2
            // 
            this.uiLine2.BackColor = System.Drawing.Color.Transparent;
            this.uiLine2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine2.Location = new System.Drawing.Point(30, 55);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(670, 20);
            this.uiLine2.TabIndex = 66;
            this.uiLine2.Text = "UIRadioButton";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FRadioButton
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 621);
            this.Controls.Add(this.uiButton4);
            this.Controls.Add(this.uiButton2);
            this.Controls.Add(this.uiRadioButtonGroup1);
            this.Controls.Add(this.uiRadioButton12);
            this.Controls.Add(this.uiRadioButton13);
            this.Controls.Add(this.uiLabel3);
            this.Controls.Add(this.uiRadioButton9);
            this.Controls.Add(this.uiRadioButton10);
            this.Controls.Add(this.uiRadioButton11);
            this.Controls.Add(this.uiLabel2);
            this.Controls.Add(this.uiRadioButton5);
            this.Controls.Add(this.uiRadioButton7);
            this.Controls.Add(this.uiRadioButton8);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.uiRadioButton6);
            this.Controls.Add(this.uiRadioButton3);
            this.Controls.Add(this.uiRadioButton4);
            this.Controls.Add(this.uiLine3);
            this.Controls.Add(this.uiRadioButton2);
            this.Controls.Add(this.uiRadioButton1);
            this.Controls.Add(this.uiLine2);
            this.Name = "FRadioButton";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 61842;
            this.Text = "RadioButton";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UIButton uiButton4;
        private UIButton uiButton2;
        private UIRadioButtonGroup uiRadioButtonGroup1;
        private UIRadioButton uiRadioButton12;
        private UIRadioButton uiRadioButton13;
        private UILabel uiLabel3;
        private UIRadioButton uiRadioButton9;
        private UIRadioButton uiRadioButton10;
        private UIRadioButton uiRadioButton11;
        private UILabel uiLabel2;
        private UIRadioButton uiRadioButton5;
        private UIRadioButton uiRadioButton7;
        private UIRadioButton uiRadioButton8;
        private UILabel uiLabel1;
        private UIRadioButton uiRadioButton6;
        private UIRadioButton uiRadioButton3;
        private UIRadioButton uiRadioButton4;
        private UILine uiLine3;
        private UIRadioButton uiRadioButton2;
        private UIRadioButton uiRadioButton1;
        private UILine uiLine2;
    }
}