﻿
namespace Sunny.UI.Demo
{
    partial class FButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.uiSwitch3 = new Sunny.UI.UISwitch();
            this.uiSwitch4 = new Sunny.UI.UISwitch();
            this.uiSymbolButton26 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton25 = new Sunny.UI.UISymbolButton();
            this.uiImageButton4 = new Sunny.UI.UIImageButton();
            this.uiImageButton3 = new Sunny.UI.UIImageButton();
            this.uiImageButton2 = new Sunny.UI.UIImageButton();
            this.uiImageButton1 = new Sunny.UI.UIImageButton();
            this.uiLine5 = new Sunny.UI.UILine();
            this.uiSwitch2 = new Sunny.UI.UISwitch();
            this.uiLine4 = new Sunny.UI.UILine();
            this.uiSwitch1 = new Sunny.UI.UISwitch();
            this.uiSymbolButton24 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton23 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton22 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton19 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton20 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton21 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton13 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton14 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton15 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton16 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton17 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton18 = new Sunny.UI.UISymbolButton();
            this.uiLine3 = new Sunny.UI.UILine();
            this.uiSymbolButton7 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton8 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton9 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton10 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton11 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton12 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton6 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton5 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton3 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton4 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton2 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton1 = new Sunny.UI.UISymbolButton();
            this.uiLine2 = new Sunny.UI.UILine();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiButton13 = new Sunny.UI.UIButton();
            this.uiButton14 = new Sunny.UI.UIButton();
            this.uiButton15 = new Sunny.UI.UIButton();
            this.uiButton16 = new Sunny.UI.UIButton();
            this.uiButton17 = new Sunny.UI.UIButton();
            this.uiButton18 = new Sunny.UI.UIButton();
            this.uiButton4 = new Sunny.UI.UIButton();
            this.uiButton5 = new Sunny.UI.UIButton();
            this.uiButton6 = new Sunny.UI.UIButton();
            this.uiButton3 = new Sunny.UI.UIButton();
            this.uiButton2 = new Sunny.UI.UIButton();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.uiToolTip1 = new Sunny.UI.UIToolTip(this.components);
            this.uiSwitch5 = new Sunny.UI.UISwitch();
            this.uiSwitch6 = new Sunny.UI.UISwitch();
            this.uiMenuButton1 = new Sunny.UI.UIMenuButton();
            this.uiLine6 = new Sunny.UI.UILine();
            this.uiContextMenuStrip1 = new Sunny.UI.UIContextMenuStrip();
            this.菜单一ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单二ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单三ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton1)).BeginInit();
            this.uiContextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiSwitch3
            // 
            this.uiSwitch3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSwitch3.Location = new System.Drawing.Point(275, 426);
            this.uiSwitch3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSwitch3.Name = "uiSwitch3";
            this.uiSwitch3.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiSwitch3.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch3.SwitchShape = Sunny.UI.UISwitch.UISwitchShape.Square;
            this.uiSwitch3.TabIndex = 115;
            this.uiSwitch3.Text = "uiSwitch3";
            // 
            // uiSwitch4
            // 
            this.uiSwitch4.ActiveText = "On";
            this.uiSwitch4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSwitch4.InActiveText = "Off";
            this.uiSwitch4.Location = new System.Drawing.Point(193, 426);
            this.uiSwitch4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSwitch4.Name = "uiSwitch4";
            this.uiSwitch4.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch4.SwitchShape = Sunny.UI.UISwitch.UISwitchShape.Square;
            this.uiSwitch4.TabIndex = 114;
            this.uiSwitch4.Text = "uiSwitch4";
            // 
            // uiSymbolButton26
            // 
            this.uiSymbolButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton26.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton26.Image = global::Sunny.UI.Demo.Properties.Resources.save;
            this.uiSymbolButton26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiSymbolButton26.Location = new System.Drawing.Point(486, 265);
            this.uiSymbolButton26.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton26.Name = "uiSymbolButton26";
            this.uiSymbolButton26.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.uiSymbolButton26.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton26.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton26.StyleCustomMode = true;
            this.uiSymbolButton26.Symbol = 61530;
            this.uiSymbolButton26.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton26.TabIndex = 113;
            this.uiSymbolButton26.Text = "Save";
            this.uiSymbolButton26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiSymbolButton26.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton25
            // 
            this.uiSymbolButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton25.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton25.Image = global::Sunny.UI.Demo.Properties.Resources.relationship;
            this.uiSymbolButton25.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiSymbolButton25.Location = new System.Drawing.Point(600, 265);
            this.uiSymbolButton25.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton25.Name = "uiSymbolButton25";
            this.uiSymbolButton25.Padding = new System.Windows.Forms.Padding(10, 0, 5, 0);
            this.uiSymbolButton25.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton25.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton25.StyleCustomMode = true;
            this.uiSymbolButton25.Symbol = 61453;
            this.uiSymbolButton25.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton25.TabIndex = 112;
            this.uiSymbolButton25.Text = "类库";
            this.uiSymbolButton25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiSymbolButton25.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiSymbolButton25.Click += new System.EventHandler(this.uiSymbolButton25_Click);
            // 
            // uiImageButton4
            // 
            this.uiImageButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiImageButton4.Image = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton4.ImageHover = global::Sunny.UI.Demo.Properties.Resources.dashboard;
            this.uiImageButton4.ImageOffset = new System.Drawing.Point(12, 5);
            this.uiImageButton4.ImagePress = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton4.Location = new System.Drawing.Point(630, 420);
            this.uiImageButton4.Name = "uiImageButton4";
            this.uiImageButton4.Size = new System.Drawing.Size(70, 61);
            this.uiImageButton4.TabIndex = 111;
            this.uiImageButton4.TabStop = false;
            this.uiImageButton4.Text = "Home";
            this.uiImageButton4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // uiImageButton3
            // 
            this.uiImageButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiImageButton3.Image = global::Sunny.UI.Demo.Properties.Resources.save0;
            this.uiImageButton3.ImageHover = global::Sunny.UI.Demo.Properties.Resources.save;
            this.uiImageButton3.ImagePress = global::Sunny.UI.Demo.Properties.Resources.save0;
            this.uiImageButton3.Location = new System.Drawing.Point(546, 423);
            this.uiImageButton3.Name = "uiImageButton3";
            this.uiImageButton3.Size = new System.Drawing.Size(43, 35);
            this.uiImageButton3.TabIndex = 110;
            this.uiImageButton3.TabStop = false;
            this.uiImageButton3.Text = null;
            // 
            // uiImageButton2
            // 
            this.uiImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiImageButton2.Image = global::Sunny.UI.Demo.Properties.Resources.relationship0;
            this.uiImageButton2.ImageHover = global::Sunny.UI.Demo.Properties.Resources.relationship;
            this.uiImageButton2.ImagePress = global::Sunny.UI.Demo.Properties.Resources.relationship0;
            this.uiImageButton2.Location = new System.Drawing.Point(495, 423);
            this.uiImageButton2.Name = "uiImageButton2";
            this.uiImageButton2.Size = new System.Drawing.Size(43, 35);
            this.uiImageButton2.TabIndex = 109;
            this.uiImageButton2.TabStop = false;
            this.uiImageButton2.Text = null;
            // 
            // uiImageButton1
            // 
            this.uiImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiImageButton1.Image = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton1.ImageHover = global::Sunny.UI.Demo.Properties.Resources.dashboard;
            this.uiImageButton1.ImagePress = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton1.Location = new System.Drawing.Point(395, 423);
            this.uiImageButton1.Name = "uiImageButton1";
            this.uiImageButton1.Size = new System.Drawing.Size(94, 35);
            this.uiImageButton1.TabIndex = 108;
            this.uiImageButton1.TabStop = false;
            this.uiImageButton1.Text = "Home";
            this.uiImageButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLine5
            // 
            this.uiLine5.BackColor = System.Drawing.Color.Transparent;
            this.uiLine5.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine5.Location = new System.Drawing.Point(388, 397);
            this.uiLine5.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine5.Name = "uiLine5";
            this.uiLine5.Size = new System.Drawing.Size(312, 20);
            this.uiLine5.TabIndex = 107;
            this.uiLine5.Text = "UIImageButton";
            this.uiLine5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSwitch2
            // 
            this.uiSwitch2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSwitch2.Location = new System.Drawing.Point(112, 426);
            this.uiSwitch2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSwitch2.Name = "uiSwitch2";
            this.uiSwitch2.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiSwitch2.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch2.TabIndex = 106;
            this.uiSwitch2.Text = "uiSwitch2";
            // 
            // uiLine4
            // 
            this.uiLine4.BackColor = System.Drawing.Color.Transparent;
            this.uiLine4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine4.Location = new System.Drawing.Point(30, 397);
            this.uiLine4.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine4.Name = "uiLine4";
            this.uiLine4.Size = new System.Drawing.Size(312, 20);
            this.uiLine4.TabIndex = 105;
            this.uiLine4.Text = "UISwitch";
            this.uiLine4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSwitch1
            // 
            this.uiSwitch1.ActiveText = "On";
            this.uiSwitch1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSwitch1.InActiveText = "Off";
            this.uiSwitch1.Location = new System.Drawing.Point(30, 426);
            this.uiSwitch1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSwitch1.Name = "uiSwitch1";
            this.uiSwitch1.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch1.TabIndex = 104;
            this.uiSwitch1.Text = "uiSwitch1";
            this.uiSwitch1.ValueChanged += new Sunny.UI.UISwitch.OnValueChanged(this.uiSwitch1_ValueChanged);
            this.uiSwitch1.ActiveChanging += new Sunny.UI.OnCancelEventArgs(this.uiSwitch1_ActiveChanging);
            // 
            // uiSymbolButton24
            // 
            this.uiSymbolButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton24.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton24.Location = new System.Drawing.Point(654, 345);
            this.uiSymbolButton24.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton24.Name = "uiSymbolButton24";
            this.uiSymbolButton24.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightTop | Sunny.UI.UICornerRadiusSides.RightBottom)));
            this.uiSymbolButton24.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton24.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton24.Symbol = 361473;
            this.uiSymbolButton24.TabIndex = 103;
            this.uiSymbolButton24.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton23
            // 
            this.uiSymbolButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton23.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton23.Location = new System.Drawing.Point(608, 345);
            this.uiSymbolButton23.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton23.Name = "uiSymbolButton23";
            this.uiSymbolButton23.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton23.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton23.Symbol = 361544;
            this.uiSymbolButton23.TabIndex = 102;
            this.uiSymbolButton23.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton22
            // 
            this.uiSymbolButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton22.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton22.Location = new System.Drawing.Point(562, 345);
            this.uiSymbolButton22.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton22.Name = "uiSymbolButton22";
            this.uiSymbolButton22.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton22.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton22.Symbol = 361508;
            this.uiSymbolButton22.TabIndex = 101;
            this.uiSymbolButton22.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton19
            // 
            this.uiSymbolButton19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton19.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton19.Location = new System.Drawing.Point(516, 345);
            this.uiSymbolButton19.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton19.Name = "uiSymbolButton19";
            this.uiSymbolButton19.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.LeftTop | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiSymbolButton19.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton19.Symbol = 361543;
            this.uiSymbolButton19.TabIndex = 100;
            this.uiSymbolButton19.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton20
            // 
            this.uiSymbolButton20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton20.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton20.Location = new System.Drawing.Point(352, 345);
            this.uiSymbolButton20.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton20.Name = "uiSymbolButton20";
            this.uiSymbolButton20.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightTop | Sunny.UI.UICornerRadiusSides.RightBottom)));
            this.uiSymbolButton20.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton20.Symbol = 361522;
            this.uiSymbolButton20.TabIndex = 99;
            this.uiSymbolButton20.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton21
            // 
            this.uiSymbolButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton21.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton21.Location = new System.Drawing.Point(306, 345);
            this.uiSymbolButton21.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton21.Name = "uiSymbolButton21";
            this.uiSymbolButton21.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton21.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton21.Symbol = 361520;
            this.uiSymbolButton21.TabIndex = 98;
            this.uiSymbolButton21.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton13
            // 
            this.uiSymbolButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton13.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton13.Location = new System.Drawing.Point(260, 345);
            this.uiSymbolButton13.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton13.Name = "uiSymbolButton13";
            this.uiSymbolButton13.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton13.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton13.Symbol = 361518;
            this.uiSymbolButton13.TabIndex = 97;
            this.uiSymbolButton13.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton14
            // 
            this.uiSymbolButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton14.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton14.Location = new System.Drawing.Point(214, 345);
            this.uiSymbolButton14.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton14.Name = "uiSymbolButton14";
            this.uiSymbolButton14.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton14.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton14.Symbol = 361514;
            this.uiSymbolButton14.TabIndex = 96;
            this.uiSymbolButton14.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton15
            // 
            this.uiSymbolButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton15.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton15.Location = new System.Drawing.Point(168, 345);
            this.uiSymbolButton15.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton15.Name = "uiSymbolButton15";
            this.uiSymbolButton15.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton15.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton15.Symbol = 361513;
            this.uiSymbolButton15.TabIndex = 95;
            this.uiSymbolButton15.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton16
            // 
            this.uiSymbolButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton16.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton16.Location = new System.Drawing.Point(122, 345);
            this.uiSymbolButton16.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton16.Name = "uiSymbolButton16";
            this.uiSymbolButton16.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton16.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton16.Symbol = 361517;
            this.uiSymbolButton16.TabIndex = 94;
            this.uiSymbolButton16.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton17
            // 
            this.uiSymbolButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton17.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton17.Location = new System.Drawing.Point(76, 345);
            this.uiSymbolButton17.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton17.Name = "uiSymbolButton17";
            this.uiSymbolButton17.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton17.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton17.Symbol = 361516;
            this.uiSymbolButton17.TabIndex = 93;
            this.uiSymbolButton17.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton18
            // 
            this.uiSymbolButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton18.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton18.Location = new System.Drawing.Point(30, 345);
            this.uiSymbolButton18.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton18.Name = "uiSymbolButton18";
            this.uiSymbolButton18.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.LeftTop | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiSymbolButton18.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton18.Symbol = 361515;
            this.uiSymbolButton18.TabIndex = 92;
            this.uiSymbolButton18.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiLine3
            // 
            this.uiLine3.BackColor = System.Drawing.Color.Transparent;
            this.uiLine3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine3.Location = new System.Drawing.Point(30, 315);
            this.uiLine3.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(670, 20);
            this.uiLine3.TabIndex = 91;
            this.uiLine3.Text = "UISymbolButton 按钮组";
            this.uiLine3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSymbolButton7
            // 
            this.uiSymbolButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton7.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton7.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton7.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton7.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton7.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton7.IsCircle = true;
            this.uiSymbolButton7.Location = new System.Drawing.Point(235, 265);
            this.uiSymbolButton7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton7.Name = "uiSymbolButton7";
            this.uiSymbolButton7.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton7.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton7.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton7.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton7.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton7.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton7.StyleCustomMode = true;
            this.uiSymbolButton7.Symbol = 61809;
            this.uiSymbolButton7.TabIndex = 90;
            this.uiSymbolButton7.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton8
            // 
            this.uiSymbolButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton8.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton8.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiSymbolButton8.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton8.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton8.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton8.IsCircle = true;
            this.uiSymbolButton8.Location = new System.Drawing.Point(194, 265);
            this.uiSymbolButton8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton8.Name = "uiSymbolButton8";
            this.uiSymbolButton8.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton8.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiSymbolButton8.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton8.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton8.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton8.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton8.StyleCustomMode = true;
            this.uiSymbolButton8.Symbol = 61445;
            this.uiSymbolButton8.TabIndex = 89;
            this.uiSymbolButton8.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton9
            // 
            this.uiSymbolButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton9.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton9.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiSymbolButton9.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton9.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton9.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton9.IsCircle = true;
            this.uiSymbolButton9.Location = new System.Drawing.Point(153, 265);
            this.uiSymbolButton9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton9.Name = "uiSymbolButton9";
            this.uiSymbolButton9.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton9.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiSymbolButton9.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton9.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton9.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton9.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton9.StyleCustomMode = true;
            this.uiSymbolButton9.Symbol = 57607;
            this.uiSymbolButton9.TabIndex = 88;
            this.uiSymbolButton9.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton10
            // 
            this.uiSymbolButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton10.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton10.IsCircle = true;
            this.uiSymbolButton10.Location = new System.Drawing.Point(112, 265);
            this.uiSymbolButton10.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton10.Name = "uiSymbolButton10";
            this.uiSymbolButton10.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton10.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton10.StyleCustomMode = true;
            this.uiSymbolButton10.TabIndex = 87;
            this.uiSymbolButton10.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton11
            // 
            this.uiSymbolButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton11.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton11.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton11.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton11.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton11.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton11.IsCircle = true;
            this.uiSymbolButton11.Location = new System.Drawing.Point(71, 265);
            this.uiSymbolButton11.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton11.Name = "uiSymbolButton11";
            this.uiSymbolButton11.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton11.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton11.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton11.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton11.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton11.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton11.StyleCustomMode = true;
            this.uiSymbolButton11.Symbol = 61508;
            this.uiSymbolButton11.TabIndex = 86;
            this.uiSymbolButton11.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton12
            // 
            this.uiSymbolButton12.CircleRectWidth = 2;
            this.uiSymbolButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton12.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton12.IsCircle = true;
            this.uiSymbolButton12.Location = new System.Drawing.Point(30, 265);
            this.uiSymbolButton12.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton12.Name = "uiSymbolButton12";
            this.uiSymbolButton12.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton12.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton12.StyleCustomMode = true;
            this.uiSymbolButton12.Symbol = 61442;
            this.uiSymbolButton12.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(98)))), ((int)(((byte)(102)))));
            this.uiSymbolButton12.SymbolHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton12.SymbolPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiSymbolButton12.SymbolSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiSymbolButton12.TabIndex = 85;
            this.uiSymbolButton12.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton6
            // 
            this.uiSymbolButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton6.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton6.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton6.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton6.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton6.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton6.Location = new System.Drawing.Point(600, 215);
            this.uiSymbolButton6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton6.Name = "uiSymbolButton6";
            this.uiSymbolButton6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton6.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton6.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton6.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton6.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton6.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton6.StyleCustomMode = true;
            this.uiSymbolButton6.Symbol = 361532;
            this.uiSymbolButton6.TabIndex = 84;
            this.uiSymbolButton6.Text = "Error";
            this.uiSymbolButton6.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton5
            // 
            this.uiSymbolButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton5.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton5.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiSymbolButton5.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton5.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton5.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton5.Location = new System.Drawing.Point(486, 215);
            this.uiSymbolButton5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton5.Name = "uiSymbolButton5";
            this.uiSymbolButton5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton5.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiSymbolButton5.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton5.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiSymbolButton5.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton5.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton5.StyleCustomMode = true;
            this.uiSymbolButton5.Symbol = 361553;
            this.uiSymbolButton5.TabIndex = 83;
            this.uiSymbolButton5.Text = "Warn";
            this.uiSymbolButton5.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton3
            // 
            this.uiSymbolButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton3.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton3.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiSymbolButton3.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton3.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton3.Location = new System.Drawing.Point(372, 215);
            this.uiSymbolButton3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton3.Name = "uiSymbolButton3";
            this.uiSymbolButton3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton3.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiSymbolButton3.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton3.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiSymbolButton3.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton3.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton3.StyleCustomMode = true;
            this.uiSymbolButton3.Symbol = 361530;
            this.uiSymbolButton3.TabIndex = 82;
            this.uiSymbolButton3.Text = "Success";
            this.uiSymbolButton3.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton4
            // 
            this.uiSymbolButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton4.Location = new System.Drawing.Point(258, 215);
            this.uiSymbolButton4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton4.Name = "uiSymbolButton4";
            this.uiSymbolButton4.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton4.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton4.StyleCustomMode = true;
            this.uiSymbolButton4.Symbol = 361529;
            this.uiSymbolButton4.TabIndex = 81;
            this.uiSymbolButton4.Text = "Query";
            this.uiSymbolButton4.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton2
            // 
            this.uiSymbolButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton2.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton2.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton2.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton2.Location = new System.Drawing.Point(144, 215);
            this.uiSymbolButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton2.Name = "uiSymbolButton2";
            this.uiSymbolButton2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton2.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiSymbolButton2.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton2.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiSymbolButton2.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton2.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton2.StyleCustomMode = true;
            this.uiSymbolButton2.Symbol = 361453;
            this.uiSymbolButton2.TabIndex = 80;
            this.uiSymbolButton2.Text = "Cancel";
            this.uiSymbolButton2.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiSymbolButton1
            // 
            this.uiSymbolButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSymbolButton1.Location = new System.Drawing.Point(30, 215);
            this.uiSymbolButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSymbolButton1.Name = "uiSymbolButton1";
            this.uiSymbolButton1.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton1.Style = Sunny.UI.UIStyle.Custom;
            this.uiSymbolButton1.StyleCustomMode = true;
            this.uiSymbolButton1.TabIndex = 79;
            this.uiSymbolButton1.Text = "OK";
            this.uiSymbolButton1.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiLine2
            // 
            this.uiLine2.BackColor = System.Drawing.Color.Transparent;
            this.uiLine2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine2.Location = new System.Drawing.Point(30, 185);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(670, 16);
            this.uiLine2.TabIndex = 78;
            this.uiLine2.Text = "UISymbolButton";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.Location = new System.Drawing.Point(30, 55);
            this.uiLine1.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(670, 20);
            this.uiLine1.TabIndex = 77;
            this.uiLine1.Text = "UIButton";
            this.uiLine1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiButton13
            // 
            this.uiButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton13.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton13.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton13.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton13.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton13.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton13.Location = new System.Drawing.Point(600, 135);
            this.uiButton13.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton13.Name = "uiButton13";
            this.uiButton13.Radius = 35;
            this.uiButton13.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton13.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton13.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton13.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton13.Size = new System.Drawing.Size(100, 35);
            this.uiButton13.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton13.StyleCustomMode = true;
            this.uiButton13.TabIndex = 76;
            this.uiButton13.Text = "Red";
            this.uiButton13.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton14
            // 
            this.uiButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton14.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton14.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiButton14.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton14.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton14.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton14.Location = new System.Drawing.Point(486, 135);
            this.uiButton14.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton14.Name = "uiButton14";
            this.uiButton14.Radius = 35;
            this.uiButton14.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton14.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiButton14.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton14.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton14.Size = new System.Drawing.Size(100, 35);
            this.uiButton14.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton14.StyleCustomMode = true;
            this.uiButton14.TabIndex = 75;
            this.uiButton14.Text = "Orange";
            this.uiButton14.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton15
            // 
            this.uiButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton15.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton15.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(163)))), ((int)(((byte)(163)))));
            this.uiButton15.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton15.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton15.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton15.Location = new System.Drawing.Point(372, 135);
            this.uiButton15.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton15.Name = "uiButton15";
            this.uiButton15.Radius = 35;
            this.uiButton15.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton15.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(163)))), ((int)(((byte)(163)))));
            this.uiButton15.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton15.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton15.Size = new System.Drawing.Size(100, 35);
            this.uiButton15.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton15.StyleCustomMode = true;
            this.uiButton15.TabIndex = 74;
            this.uiButton15.Text = "Gray";
            this.uiButton15.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton16
            // 
            this.uiButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton16.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton16.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiButton16.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton16.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton16.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton16.Location = new System.Drawing.Point(258, 135);
            this.uiButton16.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton16.Name = "uiButton16";
            this.uiButton16.Radius = 35;
            this.uiButton16.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton16.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiButton16.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton16.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton16.Size = new System.Drawing.Size(100, 35);
            this.uiButton16.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton16.StyleCustomMode = true;
            this.uiButton16.TabIndex = 73;
            this.uiButton16.Text = "Green";
            this.uiButton16.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton17
            // 
            this.uiButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton17.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton17.Location = new System.Drawing.Point(144, 135);
            this.uiButton17.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton17.Name = "uiButton17";
            this.uiButton17.Radius = 35;
            this.uiButton17.Size = new System.Drawing.Size(100, 35);
            this.uiButton17.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton17.StyleCustomMode = true;
            this.uiButton17.TabIndex = 72;
            this.uiButton17.Text = "Blue";
            this.uiButton17.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton18
            // 
            this.uiButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton18.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton18.Location = new System.Drawing.Point(30, 135);
            this.uiButton18.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton18.Name = "uiButton18";
            this.uiButton18.Radius = 35;
            this.uiButton18.Size = new System.Drawing.Size(100, 35);
            this.uiButton18.TabIndex = 71;
            this.uiButton18.Text = "Round";
            this.uiButton18.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton4
            // 
            this.uiButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton4.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton4.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton4.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton4.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton4.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton4.Location = new System.Drawing.Point(600, 85);
            this.uiButton4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton4.Name = "uiButton4";
            this.uiButton4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton4.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton4.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton4.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton4.ShowFocusLine = true;
            this.uiButton4.Size = new System.Drawing.Size(100, 35);
            this.uiButton4.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton4.StyleCustomMode = true;
            this.uiButton4.TabIndex = 64;
            this.uiButton4.Text = "Red";
            this.uiButton4.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton5
            // 
            this.uiButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton5.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton5.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiButton5.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton5.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton5.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton5.Location = new System.Drawing.Point(486, 85);
            this.uiButton5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton5.Name = "uiButton5";
            this.uiButton5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton5.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(175)))), ((int)(((byte)(83)))));
            this.uiButton5.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton5.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(124)))), ((int)(((byte)(32)))));
            this.uiButton5.ShowFocusLine = true;
            this.uiButton5.Size = new System.Drawing.Size(100, 35);
            this.uiButton5.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton5.StyleCustomMode = true;
            this.uiButton5.TabIndex = 63;
            this.uiButton5.Text = "Orange";
            this.uiButton5.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton6
            // 
            this.uiButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton6.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton6.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(163)))), ((int)(((byte)(163)))));
            this.uiButton6.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton6.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton6.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton6.Location = new System.Drawing.Point(372, 85);
            this.uiButton6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton6.Name = "uiButton6";
            this.uiButton6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton6.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(163)))), ((int)(((byte)(163)))));
            this.uiButton6.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton6.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.uiButton6.ShowFocusLine = true;
            this.uiButton6.Size = new System.Drawing.Size(100, 35);
            this.uiButton6.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton6.StyleCustomMode = true;
            this.uiButton6.TabIndex = 62;
            this.uiButton6.Text = "Gray";
            this.uiButton6.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton3
            // 
            this.uiButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton3.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton3.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiButton3.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton3.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton3.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton3.Location = new System.Drawing.Point(258, 85);
            this.uiButton3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton3.Name = "uiButton3";
            this.uiButton3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton3.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(203)))), ((int)(((byte)(83)))));
            this.uiButton3.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton3.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(152)))), ((int)(((byte)(32)))));
            this.uiButton3.ShowFocusLine = true;
            this.uiButton3.Size = new System.Drawing.Size(100, 35);
            this.uiButton3.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton3.StyleCustomMode = true;
            this.uiButton3.TabIndex = 61;
            this.uiButton3.Text = "Green";
            this.uiButton3.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiButton2
            // 
            this.uiButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton2.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton2.Location = new System.Drawing.Point(144, 85);
            this.uiButton2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton2.Name = "uiButton2";
            this.uiButton2.ShowFocusLine = true;
            this.uiButton2.ShowTips = true;
            this.uiButton2.Size = new System.Drawing.Size(100, 35);
            this.uiButton2.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton2.StyleCustomMode = true;
            this.uiButton2.TabIndex = 60;
            this.uiButton2.Text = "Blue";
            this.uiButton2.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton2.TipsText = "16";
            this.uiButton2.Click += new System.EventHandler(this.uiButton2_Click);
            // 
            // uiButton1
            // 
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.Font = new System.Drawing.Font("宋体", 12F);
            this.uiButton1.Location = new System.Drawing.Point(30, 85);
            this.uiButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.ShowFocusLine = true;
            this.uiButton1.Size = new System.Drawing.Size(100, 35);
            this.uiButton1.TabIndex = 59;
            this.uiButton1.Text = "System";
            this.uiButton1.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1.TipsText = "1";
            this.uiButton1.Click += new System.EventHandler(this.uiButton1_Click);
            // 
            // uiToolTip1
            // 
            this.uiToolTip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.uiToolTip1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiToolTip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uiToolTip1.OwnerDraw = true;
            // 
            // uiSwitch5
            // 
            this.uiSwitch5.ActiveText = "On";
            this.uiSwitch5.Enabled = false;
            this.uiSwitch5.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSwitch5.InActiveText = "Off";
            this.uiSwitch5.Location = new System.Drawing.Point(30, 470);
            this.uiSwitch5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSwitch5.Name = "uiSwitch5";
            this.uiSwitch5.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch5.TabIndex = 116;
            this.uiSwitch5.Text = "uiSwitch5";
            // 
            // uiSwitch6
            // 
            this.uiSwitch6.Active = true;
            this.uiSwitch6.Enabled = false;
            this.uiSwitch6.Font = new System.Drawing.Font("宋体", 12F);
            this.uiSwitch6.Location = new System.Drawing.Point(112, 470);
            this.uiSwitch6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiSwitch6.Name = "uiSwitch6";
            this.uiSwitch6.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiSwitch6.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch6.TabIndex = 117;
            this.uiSwitch6.Text = "uiSwitch6";
            // 
            // uiMenuButton1
            // 
            this.uiMenuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiMenuButton1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiMenuButton1.Location = new System.Drawing.Point(30, 554);
            this.uiMenuButton1.Menu = this.uiContextMenuStrip1;
            this.uiMenuButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiMenuButton1.Name = "uiMenuButton1";
            this.uiMenuButton1.Size = new System.Drawing.Size(180, 35);
            this.uiMenuButton1.Symbol = 361642;
            this.uiMenuButton1.TabIndex = 118;
            this.uiMenuButton1.Text = "下拉菜单按钮";
            this.uiMenuButton1.TipsFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            // 
            // uiLine6
            // 
            this.uiLine6.BackColor = System.Drawing.Color.Transparent;
            this.uiLine6.Font = new System.Drawing.Font("宋体", 12F);
            this.uiLine6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine6.Location = new System.Drawing.Point(30, 516);
            this.uiLine6.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine6.Name = "uiLine6";
            this.uiLine6.Size = new System.Drawing.Size(312, 20);
            this.uiLine6.TabIndex = 119;
            this.uiLine6.Text = "UIMenuButton";
            this.uiLine6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiContextMenuStrip1
            // 
            this.uiContextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiContextMenuStrip1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单一ToolStripMenuItem,
            this.菜单二ToolStripMenuItem,
            this.菜单三ToolStripMenuItem});
            this.uiContextMenuStrip1.Name = "uiContextMenuStrip1";
            this.uiContextMenuStrip1.Size = new System.Drawing.Size(123, 70);
            // 
            // 菜单一ToolStripMenuItem
            // 
            this.菜单一ToolStripMenuItem.Name = "菜单一ToolStripMenuItem";
            this.菜单一ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.菜单一ToolStripMenuItem.Text = "菜单一";
            // 
            // 菜单二ToolStripMenuItem
            // 
            this.菜单二ToolStripMenuItem.Name = "菜单二ToolStripMenuItem";
            this.菜单二ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.菜单二ToolStripMenuItem.Text = "菜单二";
            // 
            // 菜单三ToolStripMenuItem
            // 
            this.菜单三ToolStripMenuItem.Name = "菜单三ToolStripMenuItem";
            this.菜单三ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.菜单三ToolStripMenuItem.Text = "菜单三";
            // 
            // FButton
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 614);
            this.Controls.Add(this.uiLine6);
            this.Controls.Add(this.uiMenuButton1);
            this.Controls.Add(this.uiSymbolButton24);
            this.Controls.Add(this.uiSwitch6);
            this.Controls.Add(this.uiSwitch5);
            this.Controls.Add(this.uiSwitch3);
            this.Controls.Add(this.uiSwitch4);
            this.Controls.Add(this.uiSymbolButton26);
            this.Controls.Add(this.uiSymbolButton25);
            this.Controls.Add(this.uiImageButton4);
            this.Controls.Add(this.uiImageButton3);
            this.Controls.Add(this.uiImageButton2);
            this.Controls.Add(this.uiImageButton1);
            this.Controls.Add(this.uiLine5);
            this.Controls.Add(this.uiSwitch2);
            this.Controls.Add(this.uiLine4);
            this.Controls.Add(this.uiSwitch1);
            this.Controls.Add(this.uiSymbolButton23);
            this.Controls.Add(this.uiSymbolButton22);
            this.Controls.Add(this.uiSymbolButton19);
            this.Controls.Add(this.uiSymbolButton20);
            this.Controls.Add(this.uiSymbolButton21);
            this.Controls.Add(this.uiSymbolButton13);
            this.Controls.Add(this.uiSymbolButton14);
            this.Controls.Add(this.uiSymbolButton15);
            this.Controls.Add(this.uiSymbolButton16);
            this.Controls.Add(this.uiSymbolButton17);
            this.Controls.Add(this.uiSymbolButton18);
            this.Controls.Add(this.uiLine3);
            this.Controls.Add(this.uiSymbolButton7);
            this.Controls.Add(this.uiSymbolButton8);
            this.Controls.Add(this.uiSymbolButton9);
            this.Controls.Add(this.uiSymbolButton10);
            this.Controls.Add(this.uiSymbolButton11);
            this.Controls.Add(this.uiSymbolButton12);
            this.Controls.Add(this.uiSymbolButton6);
            this.Controls.Add(this.uiSymbolButton5);
            this.Controls.Add(this.uiSymbolButton3);
            this.Controls.Add(this.uiSymbolButton4);
            this.Controls.Add(this.uiSymbolButton2);
            this.Controls.Add(this.uiSymbolButton1);
            this.Controls.Add(this.uiLine2);
            this.Controls.Add(this.uiLine1);
            this.Controls.Add(this.uiButton13);
            this.Controls.Add(this.uiButton14);
            this.Controls.Add(this.uiButton15);
            this.Controls.Add(this.uiButton16);
            this.Controls.Add(this.uiButton17);
            this.Controls.Add(this.uiButton18);
            this.Controls.Add(this.uiButton4);
            this.Controls.Add(this.uiButton5);
            this.Controls.Add(this.uiButton6);
            this.Controls.Add(this.uiButton3);
            this.Controls.Add(this.uiButton2);
            this.Controls.Add(this.uiButton1);
            this.Name = "FButton";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 61640;
            this.Text = "Button";
            this.Load += new System.EventHandler(this.FButton_Load);
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton1)).EndInit();
            this.uiContextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private UISwitch uiSwitch3;
        private UISwitch uiSwitch4;
        private UISymbolButton uiSymbolButton26;
        private UISymbolButton uiSymbolButton25;
        private UIImageButton uiImageButton4;
        private UIImageButton uiImageButton3;
        private UIImageButton uiImageButton2;
        private UIImageButton uiImageButton1;
        private UILine uiLine5;
        private UISwitch uiSwitch2;
        private UILine uiLine4;
        private UISwitch uiSwitch1;
        private UISymbolButton uiSymbolButton24;
        private UISymbolButton uiSymbolButton23;
        private UISymbolButton uiSymbolButton22;
        private UISymbolButton uiSymbolButton19;
        private UISymbolButton uiSymbolButton20;
        private UISymbolButton uiSymbolButton21;
        private UISymbolButton uiSymbolButton13;
        private UISymbolButton uiSymbolButton14;
        private UISymbolButton uiSymbolButton15;
        private UISymbolButton uiSymbolButton16;
        private UISymbolButton uiSymbolButton17;
        private UISymbolButton uiSymbolButton18;
        private UILine uiLine3;
        private UISymbolButton uiSymbolButton7;
        private UISymbolButton uiSymbolButton8;
        private UISymbolButton uiSymbolButton9;
        private UISymbolButton uiSymbolButton10;
        private UISymbolButton uiSymbolButton11;
        private UISymbolButton uiSymbolButton12;
        private UISymbolButton uiSymbolButton6;
        private UISymbolButton uiSymbolButton5;
        private UISymbolButton uiSymbolButton3;
        private UISymbolButton uiSymbolButton4;
        private UISymbolButton uiSymbolButton2;
        private UISymbolButton uiSymbolButton1;
        private UILine uiLine2;
        private UILine uiLine1;
        private UIButton uiButton13;
        private UIButton uiButton14;
        private UIButton uiButton15;
        private UIButton uiButton16;
        private UIButton uiButton17;
        private UIButton uiButton18;
        private UIButton uiButton4;
        private UIButton uiButton5;
        private UIButton uiButton6;
        private UIButton uiButton3;
        private UIButton uiButton2;
        private UIButton uiButton1;
        private UIToolTip uiToolTip1;
        private UISwitch uiSwitch5;
        private UISwitch uiSwitch6;
        private UIMenuButton uiMenuButton1;
        private UILine uiLine6;
        private UIContextMenuStrip uiContextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单一ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单二ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单三ToolStripMenuItem;
    }
}