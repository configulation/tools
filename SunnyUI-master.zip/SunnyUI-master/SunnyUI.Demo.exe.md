V3.6.8    
此版本开始，SunnyUI.Demo的生成的可执行文件不包含在SunnyUI项目中    
如需要查看，请移步：[SunnyUI.Demo.exe](https://gitee.com/yhuse/SunnyUI.Demo)
或者用[VS2022 v17.8](https://learn.microsoft.com/en-us/visualstudio/releases/2022/release-notes-v17.8)版本编译源码，此版本开始支持.net8